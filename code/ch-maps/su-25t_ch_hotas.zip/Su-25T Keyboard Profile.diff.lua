local diff = {
	["keyDiffs"] = {
		["d146pnilunilcdnilvdnilvpnilvunil"] = {
			["added"] = {
				[1] = {
					["key"] = "K",
					["reformers"] = {
						[1] = "LShift",
					},
				},
			},
			["name"] = "Flaps Up",
			["removed"] = {
				[1] = {
					["key"] = "F",
					["reformers"] = {
						[1] = "LCtrl",
					},
				},
			},
		},
		["d1629pnilunilcdnilvdnilvpnilvunil"] = {
			["added"] = {
				[1] = {
					["key"] = "T",
					["reformers"] = {
						[1] = "LShift",
					},
				},
			},
			["name"] = "Elapsed Time Clock Start/Stop/Reset",
		},
		["d308pnilunilcdnilvdnilvpnilvunil"] = {
			["added"] = {
				[1] = {
					["key"] = "V",
					["reformers"] = {
						[1] = "LAlt",
					},
				},
			},
			["name"] = "Ripple Interval Decrease",
			["removed"] = {
				[1] = {
					["key"] = "V",
					["reformers"] = {
						[1] = "LShift",
					},
				},
			},
		},
	},
}
return diff